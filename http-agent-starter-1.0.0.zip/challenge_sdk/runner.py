"""
沙箱内的执行入口

这个模块**运行在容器内部**，由平台通过 `python -m challenge_sdk.runner` 启动。
选手不需要关心它，但了解它的行为有助于排查问题。

约定（平台侧按此准备目录）：

    /in/agent.py        选手提交的代码（只读）
    /in/tasks.json      本轮要执行的用例（只读）
    /out/results.json   执行结果（可写，平台读取）

    环境变量：
      CHALLENGE_LLM_BASE_URL   模型网关地址
      CHALLENGE_LLM_API_KEY    访问密钥
      CHALLENGE_SESSION_ID     评测会话 ID（用于计量归集）
      CHALLENGE_DATA_DIR       数据集目录（只读挂载）

**容器里没有隐藏用例的数据与答案**——这里只负责跑 Agent 并返回结果，判分在平台侧完成。

设计上刻意把「选手代码的输出」与「结构化结果」分开：
选手代码可以随便 print，平台只读 `/out/results.json`，不会因为选手打印日志而解析失败。
"""

from __future__ import annotations

import importlib.util
import json
import os
import sys
import time
import traceback
from pathlib import Path
from typing import Any

from .agent import BaseAgent
from .interaction import InteractionTool
from .llm import LLMClient
from .task import Task

AGENT_PATH = Path(os.environ.get("CHALLENGE_AGENT_PATH", "/in/agent.py"))
TASKS_PATH = Path(os.environ.get("CHALLENGE_TASKS_PATH", "/in/tasks.json"))
RESULTS_PATH = Path(os.environ.get("CHALLENGE_RESULTS_PATH", "/out/results.json"))


def load_agent_class(path: Path) -> type[BaseAgent]:
    """
    从选手提交的文件里加载 Agent 类。

    取「文件中定义的第一个 BaseAgent 子类」。如果选手定义了多个，
    请把要提交的那个放在最前面，或显式继承并只保留一个。
    """
    if not path.is_file():
        raise FileNotFoundError(f"选手代码不存在：{path}")

    spec = importlib.util.spec_from_file_location("participant_agent", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"无法加载选手代码：{path}")

    module = importlib.util.module_from_spec(spec)
    # 加入 sys.modules，让选手代码里的相对导入与 dataclass 正常工作
    sys.modules["participant_agent"] = module
    spec.loader.exec_module(module)

    for name, obj in vars(module).items():
        if isinstance(obj, type) and issubclass(obj, BaseAgent) and obj is not BaseAgent:
            return obj

    raise RuntimeError(
        "在提交的文件里没有找到 BaseAgent 的子类。"
        "请确认你的 Agent 继承自 challenge_sdk.BaseAgent 并实现了 workflow()"
    )


def run_task(agent_class: type[BaseAgent], task_payload: dict[str, Any]) -> dict[str, Any]:
    """执行单个用例。每个用例用独立的 Agent 实例，避免互相污染。"""
    task = Task.from_dict(task_payload)
    started = time.perf_counter()

    try:
        agent = agent_class(
            llm=LLMClient(),
            interaction_tool=InteractionTool(),
        )
    except Exception as exc:  # noqa: BLE001 - 实例化失败也要如实返回，不能让整批中断
        return {
            "case_id": task.case_id,
            "turn_index": task.turn_index,
            "status": "error",
            "payload": {"message": f"Agent 实例化失败：{type(exc).__name__}: {exc}", "items": []},
            "duration_ms": int((time.perf_counter() - started) * 1000),
            "usage": {"calls": 0, "total_tokens": 0},
        }

    agent.insert_task(task)
    result = agent.run()
    result.setdefault("case_id", task.case_id)
    result.setdefault("turn_index", task.turn_index)
    return result


def main() -> int:
    started = time.perf_counter()

    # ---------- 准备输出目录 ----------
    RESULTS_PATH.parent.mkdir(parents=True, exist_ok=True)

    # ---------- 加载选手代码 ----------
    try:
        agent_class = load_agent_class(AGENT_PATH)
    except Exception as exc:  # noqa: BLE001 - 加载失败要给出可读原因
        _write(
            {
                "ok": False,
                "stage": "load",
                "error": f"{type(exc).__name__}: {exc}",
                "traceback": traceback.format_exc(limit=5),
                "results": [],
            }
        )
        print(f"[runner] 加载选手代码失败：{exc}", file=sys.stderr)
        return 2

    # ---------- 读取用例 ----------
    try:
        tasks = json.loads(TASKS_PATH.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        _write(
            {
                "ok": False,
                "stage": "tasks",
                "error": f"读取用例失败：{exc}",
                "results": [],
            }
        )
        return 2

    # ---------- 逐个执行 ----------
    results: list[dict[str, Any]] = []
    for payload in tasks:
        # 单个用例崩溃不影响其余用例——这是刻意的：
        # 一个用例失败就让整批作废，对选手不公平，也让排查失去线索。
        try:
            results.append(run_task(agent_class, payload))
        except Exception as exc:  # noqa: BLE001
            results.append(
                {
                    "case_id": str(payload.get("case_id", "")),
                    "turn_index": int(payload.get("turn_index", 1)),
                    "status": "error",
                    "payload": {"message": f"执行异常：{type(exc).__name__}: {exc}", "items": []},
                    "duration_ms": 0,
                    "usage": {"calls": 0, "total_tokens": 0},
                }
            )

    _write(
        {
            "ok": True,
            "results": results,
            "total_duration_ms": int((time.perf_counter() - started) * 1000),
        }
    )
    return 0


def _write(payload: dict[str, Any]) -> None:
    RESULTS_PATH.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )


if __name__ == "__main__":
    sys.exit(main())
