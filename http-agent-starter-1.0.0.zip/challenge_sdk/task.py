"""
任务数据结构

平台把用例下发给 Agent 时，用的是这个结构。
选手在 `workflow()` 里通过 `self.task` 读取。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Task:
    """
    一个评测用例。

    `payload` 承载用例的具体参数（例如检索条件、目标对象等），
    其字段由赛题定义，选手按赛题说明读取。
    """

    #: 用例 ID
    case_id: str
    #: 用例类型：chat / single / multi
    case_type: str
    #: 本轮的会话 ID。多轮用例的同一会话会复用同一个值。
    session_id: str
    #: 用例参数，字段由赛题定义
    payload: dict[str, Any] = field(default_factory=dict)
    #: 当前是第几轮（从 1 开始）；单轮用例恒为 1
    turn_index: int = 1
    #: 该会话的总轮数
    total_turns: int = 1

    @property
    def is_first_turn(self) -> bool:
        return self.turn_index == 1

    @property
    def is_last_turn(self) -> bool:
        return self.turn_index >= self.total_turns

    def get(self, key: str, default: Any = None) -> Any:
        """便捷读取 payload 字段"""
        return self.payload.get(key, default)

    def to_dict(self) -> dict[str, Any]:
        return {
            "case_id": self.case_id,
            "case_type": self.case_type,
            "session_id": self.session_id,
            "payload": self.payload,
            "turn_index": self.turn_index,
            "total_turns": self.total_turns,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Task:
        return cls(
            case_id=str(data.get("case_id", "")),
            case_type=str(data.get("case_type", "single")),
            session_id=str(data.get("session_id", "")),
            payload=dict(data.get("payload") or {}),
            turn_index=int(data.get("turn_index", 1)),
            total_turns=int(data.get("total_turns", 1)),
        )


@dataclass
class TaskResult:
    """
    Agent 的返回结果。

    两种形态：
      · **对话类**：只填 `reply`，返回自然语言即可
      · **任务类**：填 `items`（结构化结果列表），SDK 会自动序列化

    `reply` 面向用户，`items` 面向评分。两者都需要时都填。
    """

    #: 面向用户的自然语言回复
    reply: str = ""
    #: 结构化结果。评分比对的就是它。
    items: list[str] = field(default_factory=list)
    #: 可选的补充说明（如引用的来源），不参与评分，供排查使用
    notes: dict[str, Any] = field(default_factory=dict)

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"message": self.reply, "items": list(self.items)}
        if self.notes:
            payload["notes"] = self.notes
        return payload
