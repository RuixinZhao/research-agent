"""
数据访问工具

**这是 Agent 获取数据的唯一途径。** 赛题规则要求所有数据访问都经过本工具，
禁止直连数据库、禁止抓取外部数据源。

实现上它读取挂载到容器内的数据集目录——因此**容器里有什么数据，Agent 就只能访问什么数据**。
这是最干净的数据访问控制方式：不需要额外的服务与鉴权，
平台只要不把敏感数据挂进去即可。

> 关键推论：**隐藏用例的数据与答案永远不会出现在容器里**。
> 容器只负责跑 Agent 并返回结果，判分在平台侧完成。

本地调试时把样例数据目录传给 `data_dir` 即可，用法与平台评测时完全一致。
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


class DataAccessError(RuntimeError):
    """数据访问失败"""


class InteractionTool:
    """
    受控数据访问工具。

    数据目录结构（由赛题定义，此处为当前示例）：

        <data_dir>/
        ├── items.json     条目主表
        └── users.json     用户表

    平台评测时会把这个目录以只读方式挂载进容器；
    本地调试时用 `data_dir="sdk/data/samples"` 即可。
    """

    def __init__(self, data_dir: str | os.PathLike[str] | None = None) -> None:
        self.data_dir = data_dir or os.environ.get("CHALLENGE_DATA_DIR") or None
        #: 懒加载 + 缓存：避免每次调用都重新读整个文件
        self._cache: dict[str, Any] = {}

    # ---------------------------------------------------------------- 内部

    def _load(self, name: str) -> Any:
        if name in self._cache:
            return self._cache[name]

        if not self.data_dir:
            raise DataAccessError(
                "未配置数据目录。请设置环境变量 CHALLENGE_DATA_DIR，"
                "或在构造 InteractionTool 时传入 data_dir"
            )

        path = Path(self.data_dir) / f"{name}.json"
        if not path.is_file():
            raise DataAccessError(f"数据文件不存在：{path}")

        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except ValueError as exc:
            raise DataAccessError(f"数据文件格式错误：{path}（{exc}）") from exc

        self._cache[name] = payload
        return payload

    # ---------------------------------------------------------------- 查询

    def search_items(self, query: str = "", limit: int = 20) -> list[dict[str, Any]]:
        """
        检索条目。

        `query` 的匹配规则由赛题定义；当前实现为「子串匹配标题或摘要」。
        赛题确定后请按实际数据源替换本方法的匹配逻辑。
        """
        items = self._load("items")
        if not isinstance(items, list):
            raise DataAccessError("items.json 顶层必须是数组")

        keyword = (query or "").strip().lower()
        if not keyword:
            return items[:limit]

        matched = [
            item
            for item in items
            if keyword in str(item.get("title", "")).lower()
            or keyword in str(item.get("summary", "")).lower()
            or keyword in str(item.get("content", "")).lower()
        ]
        return matched[:limit]

    def get_item(self, item_id: str) -> dict[str, Any]:
        """按 ID 读取单条数据"""
        items = self._load("items")
        for item in items if isinstance(items, list) else []:
            if str(item.get("id")) == str(item_id):
                return item
        raise DataAccessError(f"条目不存在：{item_id}")

    def get_user(self, user_id: str) -> dict[str, Any]:
        """按 ID 读取用户数据"""
        users = self._load("users")
        for user in users if isinstance(users, list) else []:
            if str(user.get("id")) == str(user_id):
                return user
        raise DataAccessError(f"用户不存在：{user_id}")

    def list_item_ids(self) -> list[str]:
        """列出全部条目 ID（用于自查覆盖率）"""
        items = self._load("items")
        return [str(item.get("id")) for item in items if isinstance(item, dict)]

    def stats(self) -> dict[str, int]:
        """数据集规模，便于选手确认数据是否加载正常"""
        try:
            items = self._load("items")
            item_count = len(items) if isinstance(items, list) else 0
        except DataAccessError:
            item_count = 0
        try:
            users = self._load("users")
            user_count = len(users) if isinstance(users, list) else 0
        except DataAccessError:
            user_count = 0
        return {"items": item_count, "users": user_count}
