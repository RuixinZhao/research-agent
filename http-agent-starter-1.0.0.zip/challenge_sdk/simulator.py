"""
本地模拟器

供选手在本地跑通并自测。**它使用与平台一致的评分口径**，
因此本地分数可以作为提交前的参考。

用法：

    from challenge_sdk import Simulator, BaseAgent, TaskResult

    class MyAgent(BaseAgent):
        def workflow(self):
            ...

    sim = Simulator(data_dir="data/samples")
    sim.set_agent(MyAgent)
    report = sim.run()
    print(report.summary())

⚠️ 本地分数仅供参考。平台使用不同的用例集，且隐藏集的分数权重更高。
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .agent import BaseAgent
from .interaction import InteractionTool
from .llm import LLMClient
from .task import Task


@dataclass
class CaseOutcome:
    case_id: str
    case_type: str
    status: str
    duration_ms: int
    produced: list[str] = field(default_factory=list)
    expected: list[str] = field(default_factory=list)
    error: str = ""

    @property
    def hit_ratio(self) -> float:
        if not self.expected:
            return 0.0
        produced_set = {str(item).strip().upper() for item in self.produced}
        expected_set = {str(item).strip().upper() for item in self.expected}
        return len(produced_set & expected_set) / len(expected_set)


@dataclass
class SimulatorReport:
    outcomes: list[CaseOutcome]
    total_tokens: int
    total_duration_ms: int

    @property
    def scored_cases(self) -> list[CaseOutcome]:
        return [item for item in self.outcomes if item.expected]

    @property
    def hit_rate(self) -> float:
        """命中率：与平台口径一致的简化版"""
        scored = self.scored_cases
        if not scored:
            return 0.0
        return round(sum(item.hit_ratio for item in scored) / len(scored), 4)

    @property
    def success_rate(self) -> float:
        if not self.outcomes:
            return 0.0
        ok = sum(1 for item in self.outcomes if item.status == "success")
        return round(ok / len(self.outcomes), 4)

    def summary(self) -> str:
        lines = [
            "",
            "=" * 52,
            f"用例数      {len(self.outcomes)}",
            f"执行成功率  {self.success_rate:.1%}",
            f"命中率      {self.hit_rate:.1%}（仅统计有标准答案的用例）",
            f"总 token    {self.total_tokens:,}",
            f"总耗时      {self.total_duration_ms / 1000:.1f}s",
            "=" * 52,
        ]
        failed = [item for item in self.outcomes if item.status != "success"]
        if failed:
            lines.append("")
            lines.append("失败用例：")
            for item in failed[:5]:
                lines.append(f"  {item.case_id}  {item.error[:80]}")
        return "\n".join(lines)


class Simulator:
    """本地评测模拟器"""

    def __init__(
        self,
        *,
        data_dir: str | Path,
        llm: LLMClient | None = None,
    ) -> None:
        self.data_dir = Path(data_dir)
        self.llm = llm
        self.agent_class: type[BaseAgent] | None = None
        self.tasks: list[Task] = []
        self.groundtruth: dict[str, list[str]] = {}

    # ---------------------------------------------------------------- 装配

    def set_agent(self, agent_class: type[BaseAgent]) -> None:
        if not issubclass(agent_class, BaseAgent):
            raise TypeError("Agent 必须继承 BaseAgent")
        self.agent_class = agent_class

    def load_cases(self, cases_file: str | Path | None = None) -> None:
        """
        载入本地用例。

        `cases_file` 默认为 `<data_dir>/cases.json`，格式：

            [
              {"case_id": "...", "case_type": "single", "payload": {...},
               "turns": ["..."], "expected": ["DOC_01", "DOC_02"]}
            ]

        `expected` 可缺省——缺省的用例只验证能否跑通，不参与命中率统计。
        """
        path = Path(cases_file) if cases_file else self.data_dir / "cases.json"
        if not path.is_file():
            raise FileNotFoundError(f"用例文件不存在：{path}")

        raw = json.loads(path.read_text(encoding="utf-8"))
        self.tasks = []
        self.groundtruth = {}

        for entry in raw:
            case_id = str(entry.get("case_id") or entry.get("id") or "")
            turns = entry.get("turns") or [entry.get("message", "")]
            for index, message in enumerate(turns, start=1):
                payload = dict(entry.get("payload") or {})
                payload.setdefault("message", message)
                self.tasks.append(
                    Task(
                        case_id=case_id,
                        case_type=str(entry.get("case_type") or "single"),
                        session_id=f"local-{case_id}",
                        payload=payload,
                        turn_index=index,
                        total_turns=len(turns),
                    )
                )
            if entry.get("expected"):
                self.groundtruth[case_id] = [str(item) for item in entry["expected"]]

    # ---------------------------------------------------------------- 执行

    def run(self, *, limit: int | None = None) -> SimulatorReport:
        """跑一遍全部用例"""
        if self.agent_class is None:
            raise RuntimeError("未设置 Agent：请先调用 set_agent()")
        if not self.tasks:
            raise RuntimeError("未载入用例：请先调用 load_cases()")

        tasks = self.tasks[:limit] if limit else self.tasks
        started = time.perf_counter()
        outcomes: list[CaseOutcome] = []
        total_tokens = 0

        # 每个任务一个独立的 Agent 实例，避免用例之间互相污染
        for task in tasks:
            agent = self.agent_class(
                llm=self.llm or LLMClient(),
                interaction_tool=InteractionTool(data_dir=self.data_dir),
            )
            agent.insert_task(task)

            result = agent.run()
            usage = result.get("usage") or {}
            total_tokens += int(usage.get("total_tokens") or 0)

            payload = result.get("payload") or {}
            outcomes.append(
                CaseOutcome(
                    case_id=task.case_id,
                    case_type=task.case_type,
                    status=str(result.get("status") or "unknown"),
                    duration_ms=int(result.get("duration_ms") or 0),
                    produced=[str(item) for item in (payload.get("items") or [])],
                    expected=self.groundtruth.get(task.case_id, []),
                    error=str(payload.get("message") or "") if result.get("status") != "success" else "",
                )
            )

        return SimulatorReport(
            outcomes=outcomes,
            total_tokens=total_tokens,
            total_duration_ms=int((time.perf_counter() - started) * 1000),
        )
