"""
大赛 Agent 开发 SDK

选手只需继承 `BaseAgent` 并实现 `workflow()`：

    from challenge_sdk import BaseAgent, TaskResult

    class MyAgent(BaseAgent):
        def workflow(self) -> TaskResult:
            query = self.task.get("query", "")
            candidates = self.interaction_tool.search_items(query, limit=5)

            prompt = f"根据以下候选，选出最相关的 3 条：{candidates}"
            answer = self.llm.chat([{"role": "user", "content": prompt}])

            return TaskResult(reply=answer.content, items=[c["id"] for c in candidates[:3]])

三条必须遵守的规则：

1. **数据访问只能通过 `self.interaction_tool`** —— 不要直接读文件、不要连数据库
2. **模型调用只能通过 `self.llm`** —— 不要自己发 HTTP 请求、不要用外部模型
3. **结果要放进 `TaskResult.items`** —— 评分比对的是它
"""

from .agent import BaseAgent
from .interaction import DataAccessError, InteractionTool
from .llm import LLMClient, LLMError, LLMResponse
from .simulator import CaseOutcome, Simulator, SimulatorReport
from .task import Task, TaskResult

__version__ = "1.0.0"

__all__ = [
    "BaseAgent",
    "CaseOutcome",
    "DataAccessError",
    "InteractionTool",
    "LLMClient",
    "LLMError",
    "LLMResponse",
    "Simulator",
    "SimulatorReport",
    "Task",
    "TaskResult",
    "__version__",
]
