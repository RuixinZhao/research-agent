"""
Agent 基类

选手只需要继承 `BaseAgent` 并实现 `workflow()`，其余由 SDK 负责：

    · 会话上下文的隔离与清理（按 session_id）
    · 结果序列化（保证 `items` 字段是纯 JSON，不会带自然语言前缀）
    · 用量统计（token 与调用次数）
    · 异常兜底（任何异常都返回合规结果，而不是让平台拿到崩溃）

> **为什么上下文隔离很关键**：平台会对同一个 `session_id` 多次调用（多轮用例），
> 也会用新的 `session_id` 重新评测。如果把上下文放在全局变量里而不区分 session_id，
> 第二次评测会带着上一次的记忆作答，成绩异常且极难排查。SDK 已经替你处理好了。
"""

from __future__ import annotations

import abc
import time
import traceback
from typing import Any

from .interaction import InteractionTool
from .llm import LLMClient
from .task import Task, TaskResult


class BaseAgent(abc.ABC):
    """所有参赛 Agent 的基类"""

    def __init__(
        self,
        *,
        llm: LLMClient | None = None,
        interaction_tool: InteractionTool | None = None,
    ) -> None:
        self.llm = llm or LLMClient()
        self.interaction_tool = interaction_tool or InteractionTool()

        #: 由平台在每次任务下发前注入
        self.task: Task | None = None
        #: 本会话的历史（按 session_id 隔离，见 `_sessions`）
        self.history: list[dict[str, str]] = []

        self._sessions: dict[str, list[dict[str, str]]] = {}
        self._started_at = time.perf_counter()

    # ---------------------------------------------------------------- 生命周期

    def insert_task(self, task: Task) -> None:
        """
        注入任务。由平台/SDK 调用，选手无需关心。

        同时按 `session_id` 恢复该会话的历史上下文——
        这样多轮用例能记住前几轮说了什么，而不同会话之间互不影响。
        """
        self.task = task
        self.history = self._sessions.setdefault(task.session_id, [])

    def reset_session(self, session_id: str) -> None:
        """清空指定会话的上下文"""
        self._sessions.pop(session_id, None)

    # ---------------------------------------------------------------- 待实现

    @abc.abstractmethod
    def workflow(self) -> TaskResult | str | tuple[Any, ...] | dict[str, Any]:
        """
        **选手需要实现的方法。**

        返回值可以是：
          · `TaskResult`            —— 推荐，语义最清晰
          · `str`                   —— 等价于 `TaskResult(reply=...)`
          · `list[str]`             —— 等价于 `TaskResult(items=...)`
          · `dict`                  —— 直接作为结构化结果返回

        实现要点：
          1. 用 `self.task` 读取用例参数
          2. 用 `self.interaction_tool` 取数据（不要直接读文件）
          3. 用 `self.llm` 调模型（不要自己发 HTTP 请求）
          4. 把结果整理成 `TaskResult` 返回

        标注为抽象方法是有意为之：**没实现 workflow 的 Agent 在实例化时就会报错**，
        而不是等到评测跑到一半才失败。报错信息也更直白。
        """
        raise NotImplementedError

    # ---------------------------------------------------------------- 执行

    def run(self) -> dict[str, Any]:
        """
        执行一次任务并返回平台可消费的结果。

        由平台/SDK 调用，选手通常不需要重写。
        **任何异常都会被兜住**——评测期间一次崩溃不应该让整个用例判为平台故障。
        """
        self._started_at = time.perf_counter()

        try:
            raw = self.workflow()
        except Exception as exc:  # noqa: BLE001 - 选手代码不可信，必须兜住
            detail = traceback.format_exc(limit=3)
            return self._failure(f"{type(exc).__name__}: {exc}", detail=detail)

        result = self._normalize(raw)
        return {
            "status": "success",
            "payload": result.to_payload(),
            "duration_ms": int((time.perf_counter() - self._started_at) * 1000),
            "usage": self.llm.usage_summary(),
        }

    # ---------------------------------------------------------------- 内部

    def _normalize(self, raw: Any) -> TaskResult:
        """把选手的各种返回形态统一成 TaskResult"""
        if isinstance(raw, TaskResult):
            return raw
        if isinstance(raw, str):
            return TaskResult(reply=raw)
        if isinstance(raw, list):
            return TaskResult(items=[str(item) for item in raw])
        if isinstance(raw, dict):
            return TaskResult(
                reply=str(raw.get("message") or raw.get("reply") or ""),
                items=[str(item) for item in (raw.get("items") or [])],
                notes={
                    key: value
                    for key, value in raw.items()
                    if key not in {"message", "reply", "items"}
                },
            )
        if isinstance(raw, tuple):
            return TaskResult(items=[str(item) for item in raw])

        # 未知类型：如实说明，不要静默返回空结果
        return TaskResult(reply=f"workflow() 返回了不支持的类型：{type(raw).__name__}")

    @staticmethod
    def _failure(message: str, *, detail: str = "") -> dict[str, Any]:
        return {
            "status": "error",
            "payload": {"message": f"Agent 执行失败：{message}", "items": []},
            "detail": detail,
            "usage": {"calls": 0, "total_tokens": 0},
        }

    # ---------------------------------------------------------------- 辅助

    def remember(self, role: str, content: str) -> None:
        """
        写入会话历史。

        注意：历史越长，后续每次模型调用的 token 越多，而 token 直接换算成时间片消耗。
        建议只保留必要的信息，或在组装消息时自行截断。
        """
        self.history.append({"role": role, "content": content})

    def recent_history(self, limit: int = 8) -> list[dict[str, str]]:
        """取最近若干条历史，避免上下文无限增长"""
        return self.history[-limit:]

    def elapsed_ms(self) -> int:
        """当前任务已耗时（毫秒）"""
        return int((time.perf_counter() - self._started_at) * 1000)
