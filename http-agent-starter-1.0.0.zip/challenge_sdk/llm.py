"""
模型调用客户端

**所有模型调用必须经过本客户端**，它内部走平台提供的模型网关。

为什么强制走 SDK：
  · 平台按 token 用量核算时间片预算，绕过 SDK 就无法计量
  · 同分排名比较的是总 token 消耗，同样依赖网关统计
  · 私自调用外部模型属于作弊

配置从环境变量读取，因此**同一份代码在本地调试与平台评测时都能直接跑**：

    CHALLENGE_LLM_BASE_URL   模型网关地址
    CHALLENGE_LLM_API_KEY    访问密钥（本地调试时由组委会发放）
    CHALLENGE_SESSION_ID     当前评测会话 ID（由平台注入，用于计量归集）

本地调试时把前三项写进 `.env` 或直接导出环境变量即可。
"""

from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any


class LLMError(RuntimeError):
    """模型调用失败"""


@dataclass
class LLMResponse:
    content: str
    total_tokens: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    #: 原始响应，工具调用场景下需要读 tool_calls
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def tool_calls(self) -> list[dict[str, Any]]:
        choices = self.raw.get("choices") or []
        if not choices:
            return []
        return list((choices[0].get("message") or {}).get("tool_calls") or [])


class LLMClient:
    """
    模型客户端。

    用量统计：`total_tokens_used` 累计本次运行消耗的 token，
    选手可以用它自查是否接近时间片预算（token 直接换算时间片）。
    """

    def __init__(
        self,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        model: str | None = None,
        session_id: str | None = None,
        timeout: float = 60.0,
        max_retries: int | None = None,
    ) -> None:
        self.base_url = _normalize_base_url(
            base_url or os.environ.get("CHALLENGE_LLM_BASE_URL") or ""
        )
        self.api_key = api_key or os.environ.get("CHALLENGE_LLM_API_KEY") or ""
        self.model = (
            model
            or os.environ.get("CHALLENGE_LLM_MODEL")
            or os.environ.get("CHALLENGE_LLM_MODEL_NAME")
            or ""
        )
        self.session_id = session_id or os.environ.get("CHALLENGE_SESSION_ID") or ""
        self.timeout = float(os.environ.get("CHALLENGE_LLM_TIMEOUT_S", timeout))
        configured_retries = os.environ.get("CHALLENGE_LLM_MAX_RETRIES", "2")
        self.max_retries = max(0, int(max_retries if max_retries is not None else configured_retries))
        self.total_tokens_used = 0
        self.call_count = 0
        self.total_duration_ms = 0

        # 刻意**不在构造时**报错：不用模型的 Agent 不应该因为没配网关就起不来。
        # 缺配置的提示推迟到真正调用时给出，那时信息也更相关。
        self._config_warning = (
            None
            if self.base_url
            else "未配置模型网关地址（环境变量 CHALLENGE_LLM_BASE_URL），调用模型时会失败"
        )

    # ---------------------------------------------------------------- 调用

    def chat(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.2,
        max_tokens: int | None = None,
    ) -> LLMResponse:
        """发起一次对话补全"""
        if not self.base_url:
            raise LLMError(
                "未配置模型网关地址。请设置环境变量 CHALLENGE_LLM_BASE_URL，"
                "或在构造 LLMClient 时显式传入 base_url"
            )

        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "temperature": temperature,
        }
        if tools:
            payload["tools"] = tools
        if max_tokens:
            payload["max_tokens"] = max_tokens

        headers = {
            "Content-Type": "application/json",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        # 会话 ID 让平台把用量归集到本次评测；缺了它统计会不准
        if self.session_id:
            headers["Session-ID"] = self.session_id
        # The gateway may safely replay a request with this key after a
        # transport timeout. It also lets the platform correlate retries.
        request_id = self.session_id or "session"
        headers["Idempotency-Key"] = f"{request_id}-{self.call_count + 1}"

        request = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers=headers,
            method="POST",
        )

        started = time.perf_counter()
        last_error: LLMError | None = None
        for attempt in range(self.max_retries + 1):
            try:
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    body = json.loads(response.read())
                last_error = None
                break
            except urllib.error.HTTPError as exc:
                detail = ""
                try:
                    detail = exc.read().decode("utf-8", "ignore")[:300]
                except Exception:  # noqa: BLE001 - 读不到详情不应覆盖原始错误
                    pass
                last_error = LLMError(f"模型网关返回 {exc.code}：{detail}")
                if exc.code not in {408, 409, 425, 429} and exc.code < 500:
                    break
            except urllib.error.URLError as exc:
                last_error = LLMError(f"无法连接模型网关：{exc.reason}")
            except TimeoutError:
                last_error = LLMError(f"模型调用超时（{self.timeout}s）")
            if attempt < self.max_retries:
                time.sleep(min(0.25 * (2**attempt), 1.0))
        self.total_duration_ms += int((time.perf_counter() - started) * 1000)
        if last_error is not None:
            raise last_error

        choices = body.get("choices") or []
        if not choices:
            raise LLMError(f"模型返回内容为空：{body}")

        usage = body.get("usage") or {}
        total = int(usage.get("total_tokens") or 0)

        self.call_count += 1
        self.total_tokens_used += total

        return LLMResponse(
            content=str((choices[0].get("message") or {}).get("content") or ""),
            total_tokens=total,
            prompt_tokens=int(usage.get("prompt_tokens") or 0),
            completion_tokens=int(usage.get("completion_tokens") or 0),
            raw=body,
        )

    def __call__(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> LLMResponse:
        """让 LLMClient 可以像函数一样调用，写起来更顺手"""
        return self.chat(messages, **kwargs)

    # ---------------------------------------------------------------- 自查

    def usage_summary(self) -> dict[str, Any]:
        """
        本次运行的用量摘要。

        时间片消耗约等于 `ceil(1 + max(0, tokens - 1024) * 0.3 / 1024)` 的逐次累加，
        因此**单次调用的 token 越少越好**：超过 1024 一点点就会从 1 片跳到 2 片。
        """
        return {
            "calls": self.call_count,
            "total_tokens": self.total_tokens_used,
            "duration_ms": self.total_duration_ms,
            "avg_tokens_per_call": (
                round(self.total_tokens_used / self.call_count) if self.call_count else 0
            ),
        }


def _normalize_base_url(value: str) -> str:
    """Accept either an origin or an OpenAI-compatible ``/v1`` base URL."""
    normalized = value.strip().rstrip("/")
    if normalized.endswith("/chat/completions"):
        return normalized[: -len("/chat/completions")]
    if normalized.endswith("/v1"):
        return normalized
    return f"{normalized}/v1" if normalized else ""
