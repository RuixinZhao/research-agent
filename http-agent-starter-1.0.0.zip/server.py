"""Minimal stateful Agent HTTP service implementing the competition contract."""

from __future__ import annotations

import json
import os
import re
import threading
import time
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

from challenge_sdk import LLMClient, LLMError

HOST = "0.0.0.0"
PORT = int(os.environ.get("PORT", "8080"))
MAX_BODY_BYTES = 8 * 1024 * 1024
MAX_CACHED_TASKS = 512
LOCK = threading.Lock()
SESSIONS: dict[str, list[dict[str, str]]] = {}
IDEMPOTENT_RESULTS: OrderedDict[str, dict[str, Any]] = OrderedDict()


class AgentHandler(BaseHTTPRequestHandler):
    server_version = "AgentStarter/1.0"

    def do_GET(self) -> None:
        if self.path != "/health":
            self._write(404, {"error": "not_found"})
            return
        self._write(200, {"status": "ok"})

    def do_POST(self) -> None:
        if self.path != "/solve":
            self._write(404, {"error": "not_found"})
            return

        started = time.perf_counter()
        try:
            request = self._read_json()
            task_id = request["task_id"]
            task_type = request["task_type"]
            task_input = request["input"]
            session_id = str(request.get("session_id") or task_id)
            if not isinstance(task_id, str) or not task_id:
                raise ValueError("task_id must be a non-empty string")
            if task_type not in {"qa", "code", "reasoning", "multi_turn", "tool_use"}:
                raise ValueError("unsupported task_type")
            if not isinstance(task_input, dict):
                raise ValueError("input must be an object")
            question = str(task_input.get("question") or "")
        except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
            self._write(400, {"error": {"message": str(exc)}})
            return

        # The same task_id is sent on a retry, so completed requests are returned once.
        with LOCK:
            cached = IDEMPOTENT_RESULTS.get(task_id)
            if cached is not None:
                IDEMPOTENT_RESULTS.move_to_end(task_id)
                self._write(200, cached)
                return

            history = SESSIONS.setdefault(session_id, [])
            try:
                response = self.solve_task(
                    task_id,
                    task_type,
                    question,
                    {**task_input, "constraints": request.get("constraints") or {}},
                    history,
                    started_at=started,
                )
            except LLMError as exc:
                response = {
                    "task_id": task_id,
                    "status": "timeout" if "超时" in str(exc).lower() else "error",
                    "error": {"message": str(exc)},
                    "metadata": {
                        "llm_calls": 0,
                        "tools_used": [],
                        "duration_ms": int((time.perf_counter() - started) * 1000),
                    },
                }
            if response.get("status") == "success":
                history.append({"question": question, "answer": response["output"]["answer"]})
            IDEMPOTENT_RESULTS[task_id] = response
            while len(IDEMPOTENT_RESULTS) > MAX_CACHED_TASKS:
                IDEMPOTENT_RESULTS.popitem(last=False)

        self._write(200, response)

    @staticmethod
    def solve_task(
        task_id: str,
        task_type: str,
        question: str,
        task_input: dict[str, Any],
        history: list[dict[str, str]],
        started_at: float,
    ) -> dict[str, Any]:
        """Call the competition Gateway using its OpenAI-compatible protocol."""
        context = str(task_input.get("context") or "")
        messages: list[dict[str, str]] = [
            {
                "role": "system",
                "content": (
                    "你是全国高校 Agent 网络创新挑战赛的参赛 Agent。"
                    "请直接、准确回答任务，不输出思维过程。"
                ),
            }
        ]
        for previous in history[-6:]:
            messages.append({"role": "user", "content": previous["question"]})
            messages.append({"role": "assistant", "content": previous["answer"]})
        user_content = question
        if context:
            user_content += f"\n\n参考上下文：{context}"
        messages.append({"role": "user", "content": user_content})

        constraints = task_input.get("constraints") or {}
        max_tokens = int(constraints.get("max_tokens") or os.environ.get("CHALLENGE_LLM_MAX_TOKENS", "4096"))
        client = LLMClient(session_id=os.environ.get("CHALLENGE_SESSION_ID") or task_id)
        answer = client.chat(messages, max_tokens=max_tokens).content.strip()
        if not answer:
            raise LLMError("模型网关返回空答案")
        items = list(dict.fromkeys(re.findall(r"\b[A-Za-z][A-Za-z0-9_-]*\b", answer)))
        usage = client.usage_summary()
        return {
            "task_id": task_id,
            "status": "success",
            "output": {"answer": answer, "items": items, "confidence": 0.5},
            "metadata": {
                "llm_calls": usage["calls"],
                "tools_used": [],
                "duration_ms": int((time.perf_counter() - started_at) * 1000),
            },
        }

    def _read_json(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0 or length > MAX_BODY_BYTES:
            raise ValueError("request body size is invalid")
        payload = json.loads(self.rfile.read(length))
        if not isinstance(payload, dict):
            raise ValueError("request body must be an object")
        return payload

    def _write(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args: Any) -> None:
        print("[agent] " + (format % args), flush=True)


if __name__ == "__main__":
    ThreadingHTTPServer((HOST, PORT), AgentHandler).serve_forever()
