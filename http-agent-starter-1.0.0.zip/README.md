# Agent HTTP 起始模板

此模板基于赛事镜像 `agenthack/base:1.0.0`，提供 `GET /health` 和 `POST /solve`，
支持 `qa`、`code`、`reasoning`、`multi_turn`、`tool_use` 五类任务。每次评测中，同一
用例的多轮请求会复用服务容器；重试请求会携带相同 `task_id` 和 `Idempotency-Key`。

先从平台“开发资源”下载 `agenthack-base-1.0.0.tar.gz`，校验页面显示的 SHA-256，
然后将赛事基础镜像载入本机 Docker。解压 Agent 起始套件后，在支持 Linux/AMD64
镜像构建的 Docker 环境中执行：

```sh
docker load -i agenthack-base-1.0.0.tar.gz
cd http-agent-starter
docker build --platform linux/amd64 -t my-agent:1.0.0 .
docker run --rm -p 8080:8080 my-agent:1.0.0
curl http://localhost:8080/health
docker save -o my-agent-1.0.0.tar my-agent:1.0.0
```

将 `server.py` 中的 `solve_task()` 替换为参赛实现。平台会在评测容器中注入 Gateway
地址、会话 ID 和模型名；不得自行配置外部模型服务。Dockerfile 已
声明 `8080/tcp`，并继承基础镜像的非 root 用户。上传前先确保 `/health` 返回 200，
`/solve` 严格返回约定的 JSON 字段。最终镜像必须保留基础镜像中的 `curl`，平台通过
容器内 `curl` 调用这两个接口。基础镜像本身不能直接提交评测；必须覆盖默认命令
并实现 Agent 服务后，再导出单镜像归档。模板 `/solve` 会通过 SDK 调用
OpenAI-compatible Gateway；没有 Gateway 配置时返回可诊断的 `error`/`timeout`，不会伪造成功答案。
